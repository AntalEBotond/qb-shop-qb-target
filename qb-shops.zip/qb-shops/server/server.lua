RegisterNetEvent('exter-shop:makePayment', function(type, price, basket)
    local src = source
    if GetPlayerMoney(src, type) >= tonumber(price) then
        RemoveMoney(src, type, tonumber(price))
        for _, v in pairs(basket or {}) do
            AddItem(src, v.name, v.amount)
        end
        -- length, type ordering to satisfy various cores
        Notify(src, Config.Notify["success"], 5000, 'success')
    else
        Notify(src, Config.Notify["error"], 5000, 'error')
    end
end)
